import React from 'react';

interface InotectorLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  textColor?: 'white' | 'dark' | 'auto';
  className?: string;
}

export const InotectorIcon: React.FC<{ size?: number; className?: string }> = ({
  size = 32,
  className = '',
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 drop-shadow-xs ${className}`}
    >
      <defs>
        <linearGradient id="innotectorGrad" x1="10%" y1="10%" x2="90%" y2="90%">
          <stop offset="0%" stopColor="#3dd5b0" />
          <stop offset="100%" stopColor="#25a382" />
        </linearGradient>
        <mask id="swooshMask">
          {/* Base full cross */}
          <rect width="100" height="100" fill="white" />
          {/* Diagonal organic leaf/swoosh cutter */}
          <path
            d="M 22 78 C 38 66, 62 34, 78 22 C 72 38, 38 72, 22 78 Z"
            fill="black"
          />
          <path
            d="M 18 82 Q 50 50 82 18"
            stroke="black"
            strokeWidth="11"
            strokeLinecap="round"
          />
        </mask>
      </defs>

      {/* Cross Shape composed of smooth rounded lobes */}
      <g mask="url(#swooshMask)">
        {/* Vertical pill */}
        <rect x="34" y="8" width="32" height="84" rx="16" fill="url(#innotectorGrad)" />
        {/* Horizontal pill */}
        <rect x="8" y="34" width="84" height="32" rx="16" fill="url(#innotectorGrad)" />
      </g>
    </svg>
  );
};

export const InotectorLogo: React.FC<InotectorLogoProps> = ({
  size = 'md',
  showText = true,
  textColor = 'auto',
  className = '',
}) => {
  // Dimension scales
  const iconSizes = {
    sm: 22,
    md: 28,
    lg: 38,
    xl: 52,
  };

  const textStyles = {
    sm: 'text-sm tracking-tight',
    md: 'text-base sm:text-lg tracking-tight',
    lg: 'text-xl sm:text-2xl tracking-tight',
    xl: 'text-2xl sm:text-3xl tracking-tight',
  };

  const colorClass =
    textColor === 'white'
      ? 'text-white'
      : textColor === 'dark'
      ? 'text-[#24614e]'
      : 'text-inherit';

  return (
    <div className={`inline-flex items-center gap-2 select-none ${className}`}>
      {/* Authentic High-Res Icon from User Attachment with SVG Fallback */}
      <div className="relative flex items-center justify-center shrink-0">
        <img
          src="/assets/innotector_icon.png"
          alt="Inotector Care Logo"
          className="object-contain shrink-0"
          style={{ width: iconSizes[size], height: iconSizes[size] }}
          onError={(e) => {
            // If image fails, fallback to vector SVG
            e.currentTarget.style.display = 'none';
          }}
        />
      </div>

      {showText && (
        <span
          className={`font-heading font-extrabold ${textStyles[size]} ${colorClass}`}
          style={{ letterSpacing: '-0.02em' }}
        >
          Inotector Care
        </span>
      )}
    </div>
  );
};

export default InotectorLogo;
